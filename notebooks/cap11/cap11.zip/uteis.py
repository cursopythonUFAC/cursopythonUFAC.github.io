#Vamos esconder esta célula

# Antes de proceguir vamos criar funções que irá facilitar a nossa vida
import IPython

def md(txt):
    """
    Mostra um texto em Markdown
    """
    display(IPython.display.Markdown(txt))

def Eqn(eq):
    """
    Função equação:
    Imprime uma equação centralizada
    """
    return md(fr"""\begin{{equation}}{eq}\end{{equation}}"""
    )